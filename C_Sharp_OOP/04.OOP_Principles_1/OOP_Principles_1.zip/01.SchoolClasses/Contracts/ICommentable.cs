﻿namespace _01.SchoolClasses.Contracts
{
    public interface ICommentable
    {
        string Comment { get; set; }
    }
}