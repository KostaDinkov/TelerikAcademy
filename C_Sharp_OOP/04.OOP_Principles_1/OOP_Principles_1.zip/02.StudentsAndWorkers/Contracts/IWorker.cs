﻿namespace _02.StudentsAndWorkers.Contracts
{
    public interface IWorker
    {
        decimal MoneyPerHour();
    }
}