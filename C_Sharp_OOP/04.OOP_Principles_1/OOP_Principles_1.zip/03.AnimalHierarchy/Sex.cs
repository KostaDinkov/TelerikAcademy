﻿namespace _03.AnimalHierarchy
{
    public enum Sex { Male,Female}
}