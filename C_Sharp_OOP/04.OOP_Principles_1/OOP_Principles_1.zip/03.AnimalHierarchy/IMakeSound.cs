﻿namespace _03.AnimalHierarchy
{
    public interface IMakeSound
    {
        void MakeSound();
    }
}